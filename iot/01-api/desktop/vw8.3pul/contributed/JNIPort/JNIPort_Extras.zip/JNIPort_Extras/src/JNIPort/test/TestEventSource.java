package jniport.test;

import java.util.*;

/**
 * TestEventSource.java
 *<p>
 * Copyright &copy; 2003 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class TestEventSource
{
	List<TestEventListener> m_listeners = new ArrayList<TestEventListener>();
	

	public void
	addListener(TestEventListener listener)
	{
		m_listeners.add(listener);
	}
	

	public void
	removeListener(TestEventListener listener)
	{
		m_listeners.remove(listener);
	}
	

	public void
	triggerTestEvent(String text)
	{
		TestEventObject event = new TestEventObject(this, text);
		Iterator<TestEventListener> itr = m_listeners.iterator();
		while (itr.hasNext())
		{
			TestEventListener listener = itr.next();
			listener.onTestEvent(event);
		}
	}
}
