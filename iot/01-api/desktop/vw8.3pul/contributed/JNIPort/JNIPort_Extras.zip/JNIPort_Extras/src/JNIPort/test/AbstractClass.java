package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public abstract class AbstractClass
{
	public abstract String method();

	// a ctor on an abstract class would normally be
	// protected rather than public, but we want these
	// to show up as ghost constructors
	public AbstractClass() {}
	public AbstractClass(int i) {}
}
