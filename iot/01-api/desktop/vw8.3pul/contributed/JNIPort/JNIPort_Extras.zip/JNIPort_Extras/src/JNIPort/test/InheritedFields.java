package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InheritedFields
extends InheritedFieldsBase
{
	public static void
	main(String[] args)
	{
		new InheritedFields().test();
	}

	public void
	test()
	{
		System.out.println("intField = " + intField);
		System.out.println("staticIntField = " + staticIntField);
	}
}
