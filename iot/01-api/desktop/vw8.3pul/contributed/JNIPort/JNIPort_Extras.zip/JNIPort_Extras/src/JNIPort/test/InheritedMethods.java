package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InheritedMethods
extends InheritedMethodsBase
implements InheritedMethodsInterface
{
	public int			abstractIntMethod() { return 22; }
	public int			interfaceIntMethod() { return 2222; }

	public static void
	main(String[] args)
	{
		new InheritedMethods().test();
	}

	public void
	test()
	{
		System.out.println("intMethod() = " + intMethod());
		System.out.println("abstractIntMethod() = " + abstractIntMethod());
		System.out.println("staticIntMethod() = " + staticIntMethod());
		System.out.println("interfaceIntMethod() = " + interfaceIntMethod());
	}
}
