package jniport.test;

import java.util.EventObject;

/**
 * TestEventObject.java
 *<p>
 * Copyright &copy; 2003 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class TestEventObject
extends EventObject
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7821750704185770988L;
	private String m_text;

	public
	TestEventObject(Object source, String text)
	{
		super(source);
		m_text = text;
	}

	
	public String
	getText()
	{
		return m_text;
	}


	public String
	toString()
	{
		return super.toString() + " " + m_text;
	}
}
