package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class CharArrays
{
	public static char[]
	make(int from, int to)
	{
		char[] buffer = new char[to - from];
		for (int i = from; i < to; i++)
			buffer[i-from] = (char)i;

		return buffer;
	}


	public static char[]
	make(char from, char to)
	{
		return make((int)from, (int)to);
	}
}
