package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public interface InheritedFieldsInterface
{
	static final int	interfaceIntField = 33;

	static final int	ambiguousIntField = -100;
}
