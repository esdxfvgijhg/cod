package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class Constructors
{
	private String text = "<unset>";

	public Constructors() { text = "default"; }

	public Constructors(boolean arg) { text = "boolean: " + arg; }

	public Constructors(char arg) { text = "char: " + arg; }

	public Constructors(byte arg) { text = "byte: " + arg; }

	public Constructors(short arg) { text = "short: " + arg; }

	public Constructors(int arg) { text = "int: " + arg; }

	public Constructors(long arg) { text = "long: " + arg; }

	public Constructors(float arg) { text = "float: " + arg; }

	public Constructors(double arg) { text = "double: " + arg; }

	public Constructors(java.awt.Point arg) { text = "Point: " + arg; }

	public Constructors(String arg) { text = "String: " + arg; }

	public Constructors(int i, float f) { text = "int: "+i+" float: "+f; }

	public String getText() { return text; }
}
