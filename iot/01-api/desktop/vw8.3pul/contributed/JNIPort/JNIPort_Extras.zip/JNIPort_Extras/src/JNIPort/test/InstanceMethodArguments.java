package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InstanceMethodArguments
{
	public String method() { return "<nothing>"; }

	public String method(boolean arg) { return "boolean: " + arg; }

	public String method(char arg) { return "char: " + arg; }

	public String method(byte arg) { return "byte: " + arg; }

	public String method(short arg) { return "short: " + arg; }

	public String method(int arg) { return "int: " + arg; }

	public String method(long arg) { return "long: " + arg; }

	public String method(float arg) { return "float: " + arg; }

	public String method(double arg) { return "double: " + arg; }

	public String method(java.awt.Point arg) { return "Point: " + arg; }

	public String method(String arg) { return "String: " + arg; }

	public String method(int i, float f) { return "int: "+i+" float: "+f; }
}
