package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class ByteArrays
{
	public static byte[]
	make(int from, int to)
	{
		byte[] buffer = new byte[to - from];
		for (int i = from; i < to; i++)
			buffer[i-from] = (byte)i;

		return buffer;
	}


	public static byte[]
	make(char from, char to)
	{
		return make((int)from, (int)to);
	}
}
