package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class StaticMethods
{
	public static void voidMethod() { return; }

	public static boolean booleanMethod() { return true; }

	public static char charMethod() { return '!'; }

	public static byte byteMethod() { return 20; }

	public static short shortMethod() { return 21; }

	public static int intMethod() { return 22; }

	public static long longMethod() { return 23L; }

	public static float floatMethod() { return 24F; }

	public static double doubleMethod() { return 25D; }

	public static java.awt.Point pointMethod() { return new java.awt.Point(3, 4); }

	public static String stringMethod() { return "Hi there"; }

	public static Object nullMethod() { return null; }
}
