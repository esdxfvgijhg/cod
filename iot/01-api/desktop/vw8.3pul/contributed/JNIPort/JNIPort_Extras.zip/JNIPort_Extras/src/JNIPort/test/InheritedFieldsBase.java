package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InheritedFieldsBase
{
	public int				intField = 2;

	public static int		staticIntField = 222;

	public static int		ambiguousIntField = 100;

	public static boolean	staticBooleanField = true;
}
