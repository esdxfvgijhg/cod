package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class StaticMethodArguments
{
	public static String method() { return "<nothing>"; }

	public static String method(boolean arg) { return "boolean: " + arg; }

	public static String method(char arg) { return "char: " + arg; }

	public static String method(byte arg) { return "byte: " + arg; }

	public static String method(short arg) { return "short: " + arg; }

	public static String method(int arg) { return "int: " + arg; }

	public static String method(long arg) { return "long: " + arg; }

	public static String method(float arg) { return "float: " + arg; }

	public static String method(double arg) { return "double: " + arg; }

	public static String method(java.awt.Point arg) { return "Point: " + arg; }

	public static String method(String arg) { return "String: " + arg; }

	public static String method(int i, float f) { return "int: "+i+" float: "+f; }
}
