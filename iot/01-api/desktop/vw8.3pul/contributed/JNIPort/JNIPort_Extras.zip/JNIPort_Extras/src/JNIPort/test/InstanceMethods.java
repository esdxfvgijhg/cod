package jniport.test;

/**
 * Java class for JNIPort regression tests.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
public class InstanceMethods
{
	public void voidMethod() { return; }

	public boolean booleanMethod() { return true; }

	public char charMethod() { return '!'; }

	public byte byteMethod() { return 20; }

	public short shortMethod() { return 21; }

	public int intMethod() { return 22; }

	public long longMethod() { return 23L; }

	public float floatMethod() { return 24.0F; }

	public double doubleMethod() { return 25.0D; }

	public java.awt.Point pointMethod() { return new java.awt.Point(3, 4); }

	public String stringMethod() { return "Hi there"; }

	public Object nullMethod() { return null; }
}
