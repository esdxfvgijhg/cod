package jniport;


/**
 * Helper class which defines a thread which sits in a loop trying to tell
 * Smalltalk that there are pending callbacks.
 *<p>
 * Copyright &copy; 2002 and ongoing by Chris Uppal.
 *<p>
 * @author Chris Uppal (chris.uppal@metagnostic.org)
 */
class SmalltalkNotifierThread
extends Thread
{
	private static SmalltalkNotifierThread	s_demon;

	private boolean							m_serviceRequested;
	private boolean							m_shutdownRequested;
	private int								m_callbackDepth;
	private final Thread					m_smalltalkNativeThread;


	/**
	 * Return the demon thread or nil if Smalltalk hasn't connected yet, or
	 * has already shut us down.
	 */
	public static synchronized SmalltalkNotifierThread
	getDemon()
	{
		return s_demon;
	}


	/**
	 * Set the specially designated thread where we can call out to Smalltalk
	 * directly; this is private since it is actually only called (via JNI)
	 * by Smalltalk.
	 */
	private static synchronized void
	setSmalltalkNativeThread()
	{
		s_demon = new SmalltalkNotifierThread(currentThread());
	}


	/**
	 * Close down the request service, note that this does more than just
	 * ask the service thread to exit, it means that it can't start up
	 * again until after Smalltalk next invokes setSmalltalkNativeThread()
	 */
	static synchronized void
	shutdown()
	{
		SmalltalkRequestQueue.log("Demon: shutdown()");

		if (s_demon != null)
			s_demon.requestShutdown();

		s_demon = null;
	}


	/**
	 * Create a new SmalltalkNotifier daemon thread, (but don't start it).
	 * Since there should normally only ever be one of these, we use a
	 * singleton pattern, hence the ctor is private.
	 */
	private
	SmalltalkNotifierThread(Thread thread)
	{
		super("Smalltalk notifier");
		setDaemon(true);

		m_smalltalkNativeThread = thread;
		m_callbackDepth = 0;
		m_serviceRequested = false;
		m_shutdownRequested = false;
	}


	/**
	 * Notify Smalltalk that there may be some pending requests for it to service.
	 * Depending on whether this is called from the same thread as Smalltalk runs
	 * on it will either pass the notification over to the background thread or
	 * notify Smalltalk directly (in which case it will not return until the
	 * pending requests have been dealt with from this thread).
	 */
	public void
	notifySmalltalk()
	{
		log("Demon: notifySmalltalk()");

		// if this is the special Smalltalk thread, then we *must* call directly
		// into Smalltalk (or else we'll deadlock); if not then attempting to do
		// so would block this thread but not release the locks we're holding
		// (and, futhermore, would block threads that aren't interested in the
		// result of the request) so instead we'll use the background thread to
		// send the notification -- it'll get blocked, but that won't affect
		// the calling thread
		if (runningInSmalltalkThread())
			servicePendingRequests();
		else
			sendServiceRequest();
	}


	/**
	 * Call out to Smalltalk to get it to service any outstanding requests.
	 * When this returns, all the pending items will have been dealt with.
	 * NB: This <strong>must</strong> only ever be called from the Smalltalk
	 * thread
	 */
	private void
	servicePendingRequests()
	{
		log("Demon: servicePendingRequests()");

		// the logic here is tricky.  If the queue claims to have been
		// emptied at this point, then the request that caused us to enter
		// this code must already have been consumed (by Smalltalk responding
		// to a notification from the demon thread).  If any other requests
		// are on the point of being enqueued then they'll end up prodding the
		// demon again, so there is no way that we can end up not sending a
		// necessary notification if we early-out here
		if (SmalltalkRequestQueue.queueHasBeenEmptied())
		{
			log("Demon: smalltalkNotifierMethod() -- not needed");
			return;
		}

		// we need to keep count of the depth of callbacks invoked
		// via this route, since we'd prefer not to have the demon
		// be invoking callbacks at the same time as the main thead.
		// However we can't do it with normal locks since we need to
		// be able to invoke callbacks from the main thread even while
		// the background thread is already doing so!
		synchronized (this)
		{
			++m_callbackDepth;
		}

		// now call out to Smalltalk.
		log("Demon: smalltalkNotifierMethod() -- calling");
		smalltalkNotifierMethod();
		log("Demon: smalltalkNotifierMethod() -- returned");

		// let the background thread know that it's OK to use callbacks
		// again.
		// It'd be nice to postpone this notification until *after* we've
		// returned to our caller; as it is, it is possible that if there
		// any new requests pending (submitted from other threads) then
		// they'll get serviced immediately, and this thread can be starved
		// out until the other threads have stopped bombarding Smalltalk with
		// their requests
		synchronized (this)
		{
			if (--m_callbackDepth < 1)
				notifyAll();
		}

		log("Demon: servicePendingRequests() -- returned");
	}


	/**
	 * Ask the demon thread to notify Smalltalk that there may be some
	 * pending requests for it to service.
	 * <p>
	 * This <strong>must never</strong> be called from the Smalltalk
	 * thread or from the demon thread itself.
	 * <p>
	 * Returns immediately.
	 */
	private synchronized void
	sendServiceRequest()
	{
		log("Demon: sendServiceRequest()");

		// if we haven't started running yet then do so
		if (!isAlive())
		{
			log("Demon: starting demon");
			start();
		}

		// set the flag and wake up the demon thread
		log("Demon: prodding demon");
		m_serviceRequested = true;
		notifyAll();
	}


	/**
	 * Ask the demon thread to close itself down.
	 */
	private synchronized void
	requestShutdown()
	{
		log("Demon: requestShutdown()");

		// set the flag and wake up the demon thread
		log("Demon: prodding demon");
		m_shutdownRequested = true;
		notifyAll();
	}


	/**
	 * The usual main loop of our thread.
	 */
	public void
	run()
	{
		log("Demon loop: starting");

		for (;;)
		{
			synchronized (this)
			{
				// sleep until either we've been asked to shutdown, or
				// there's a request to tell Smalltalk about *and* it is
				// not already in its loop to service outstanding requests
				while (!m_shutdownRequested
				&&     !(m_serviceRequested && m_callbackDepth < 1))
				{
					try
					{
						log("Demon loop: sleeping");
						wait();
					}
					catch (InterruptedException e)
					{
					}
					log("Demon loop: woken");
				}

				// have we been closed down ?
				if (m_shutdownRequested)
				{
					log("Demon loop: shutdown requested");
					return;
				}

				// otherwise we must be able to run.
				// set the s_serviceRequested flag to false *before* we leave
				// the critical region; we won't look at it again until we next
				// go round this loop.  Note that it is only ever set to
				// false here, i.e. from this actual thread
				m_serviceRequested = false;
			}
			
			// someone has asked us to notify Smalltalk

			// as in servicePendingRequests() (see the note there) we can
			// avoid sending the notification if the queue is empty at this
			// point, since whatever caused us to wake up must, by definition
			// have been handled
			if (SmalltalkRequestQueue.queueHasBeenEmptied())
			{
				log("Demon loop: smalltalkNotifierMethod() -- not needed");
				continue;
			}

			// we now notify Smalltalk, since this will block the caller (us)
			// without releasing any locks, we have to be sure that we've
			// already released them before we do so.  We don't bother
			// incr/decrementing the callback count since *we* are the
			// thread that is supposed to be blocked by them 
			log("Demon loop: smalltalkNotifierMethod() -- calling");
			smalltalkNotifierMethod();
			log("Demon loop: smalltalkNotifierMethod() -- returned");

			// it is quite possible that some other thread has now set
			// m_serviceRequested to true; if so then we'll immediately notify
			// Smalltalk again, even though it has probably already
			// cleared the requests queued from that thread -- so what ?
		}
	}


	/**
	 * Return whether we are running in the Smalltalk native thread.
	 */
	public boolean
	runningInSmalltalkThread()
	{
		return currentThread() == m_smalltalkNativeThread;
	}


	/**
	 * This is a native method, implemented by Smalltalk; when it returns, all
	 * the pending items will have been dealt with.
	 * <p>
	 * Smalltalk blocks the caller thread, and then executes the native code
	 * in its normal OS-level thread, and only then allows the caller to
	 * proceed.  It is important to remember that if this is called then
	 * any locks held by the caller will not be released (in the manner
	 * of wait()), and that is, at heart, the only reason for this thread
	 * to exist since it allows callers to wait() for a notification rather
	 * than leaving themselves locked, and thus potentially deadlocking
	 * Smalltalk when it tries to notify them of completion.
	 */
	private static native void
	smalltalkNotifierMethod();


	/**
	 * Write a message to the log stream if there is one
	 */
	private static void
	log(String message)
	{
		SmalltalkRequestQueue.log(message);
	}


	public String
	toString()
	{
		return getName()
			+ ", service requested:" + m_serviceRequested
			+ ", callback depth:" + m_callbackDepth;
	}
}