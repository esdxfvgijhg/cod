Parser Generator for Visualworks  See also 
	http://www.cincomsmalltalk.com:8080/CincomSmalltalkWiki/T-Gen+Parser+Generator+vw5i 

SUMMARY 
T-Gen is a general-purpose object-oriented tool for the automatic generation of string-to-object translators. It is written in Smalltalk and lives in the Smalltalk programming environment. T-Gen supports the generation of both top-down (LL) and bottom-up (LR) parsers, which will automatically generate derivation trees, abstract syntax trees, or arbitrary Smalltalk objects. The simple specification syntax and graphical user interface are intended to enhance the learning, comprehension, and usefulness of T-Gen. 

CURRENT STATUS:
No active development, maintenance only.

KNOWN PROBLEMS:
None

CHANGE HISTORY:

March 12, 2002 -- republished T-Gen Development parcel for vw7 to stop messages
	Shape-changing Tgen.TranslatorGeneratorView
	Shape-changing Tgen.TranslatorGeneratorView class

v5.0 -- code cleanup, created Tgen namespace, factored Tgen into Core, Development (of grammars), and Testing parcels

v3.0 -- code cleanup and parcelled for easier installation

v2.2.1 -- see st-www.cs.uiuc.edu/users/droberts/tgen2.2.1/tgen.html 

LEGAL INFORMATION The authors make NO WARRANTY or representation, either express or implied, with respect to this
software, its quality, accuracy, merchantability, or fitness for a particular purpose. This software is provided "AS IS", and you, its user,
assume the entire risk as to its quality and accuracy. This software is copyright (c) 1992, 1994 by Justin O. Graver. All rights reserved,
except as specified below. Permission is hereby granted to use, copy, modify, and distribute this software (or portions thereof) for any
purpose, without fee, subject to these conditions: (1) If any part of the source code for this software is distributed, then this notice must be
included, unaltered; and any additions, deletions, or changes to the original files must be clearly indicated in accompanying documentation.
(2) Permission for use of this software is granted only if the user accepts full responsibility for any undesirable consequences; the authors
accept NO LIABILITY for damages of any kind. Permission is NOT granted for the use of any authors name in advertising or publicity
relating to this software or products derived from it. We specifically permit and encourage the use of this software as the basis of
commercial products, provided that all warranty or liability claims are assumed by the product vendor. Developed under the direction of
Justin Graver. Authors include: Justin Graver, Virat Hanvivatpong, and David Wilson. 

