#ifndef SAT_DEBUGGER_H
#define SAT_DEBUGGER_H



void sat_debugger_run (void);
void sat_debugger_get_ssp (gdouble *lon, gdouble *lat);
void sat_debugger_close (void);


#endif
