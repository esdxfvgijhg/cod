---
name: Question
about: Please raise your question on our community platforms. https://www.thethingsnetwork.org/forum/ or https://thethingsnetwork.slack.com

---

:rotating_light: :stop_sign: This issue tracker is not for questions :stop_sign: :rotating_light:

Please raise your question on our community platforms:

- Forum: https://www.thethingsnetwork.org/forum/
- Slack: https://thethingsnetwork.slack.com (you can self join via https://account.thethingsnetwork.org)
