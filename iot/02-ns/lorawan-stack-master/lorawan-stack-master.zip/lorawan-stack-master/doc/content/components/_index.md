---
title: "Components"
description: ""
weight: 4
menu:
  main:
    weight: 4
---

The Things Stack is composed of a number of components. The core components Network Server, Application Server and Join Server follow the LoRaWAN Network Reference Model. The Things Stack also contains an Identity Server, Gateway Server, Console and Command-line Interface.

{{< figure src="components.png" alt="The Things Stack components" >}}
