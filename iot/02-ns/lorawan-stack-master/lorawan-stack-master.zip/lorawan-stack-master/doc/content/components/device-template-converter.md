---
title: "Device Template Converter"
description: ""
weight: 9
---

The Device Template Converter converts data to device templates for migrating networks and importing vendor-specific data.

<!--more-->

For more information, see the [Concept page]({{< ref "/concepts/end-device-templates" >}}) and [Reference]({{< ref "/reference/end-device-templates" >}}).
