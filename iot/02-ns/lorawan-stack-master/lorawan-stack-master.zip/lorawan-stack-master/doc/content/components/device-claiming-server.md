---
title: "Device Claiming Server"
description: ""
weight: 10
---

The Device Claiming Server is used to transfer end devices to a new owner's application using a claim authentication code or QR code.

<!--more-->
