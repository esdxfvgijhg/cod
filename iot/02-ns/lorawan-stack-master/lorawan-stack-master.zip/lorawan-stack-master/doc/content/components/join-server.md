---
title: "Join Server"
description: ""
weight: 5
---

The Join Server handles the LoRaWAN join flow, including Network and Application Server authentication and session key generation.

<!--more-->
