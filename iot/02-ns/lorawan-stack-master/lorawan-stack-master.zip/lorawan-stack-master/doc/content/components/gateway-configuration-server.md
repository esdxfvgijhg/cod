---
title: "Gateway Configuration Server"
description: ""
weight: 11
---

The Gateway Configuration Server generates configuration files for gateways and manages gateway firmware updates.

<!--more-->
