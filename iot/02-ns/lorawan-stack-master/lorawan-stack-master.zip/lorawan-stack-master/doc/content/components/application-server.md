---
title: "Application Server"
description: ""
weight: 4
---

The Application Server handles the LoRaWAN application layer, including uplink data decryption and decoding, downlink queuing and downlink data encoding and encryption.

It hosts an MQTT server for streaming application data and manages HTTP webhooks and pub/sub integrations.

<!--more-->
