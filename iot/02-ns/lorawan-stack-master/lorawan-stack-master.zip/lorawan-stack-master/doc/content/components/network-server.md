---
title: "Network Server"
description: ""
weight: 3
---

The Network Server handles the LoRaWAN network layer, including MAC commands, regional parameters and adaptive data rate (ADR).

<!--more-->
