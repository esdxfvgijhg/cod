---
title: "Email Templates"
description: ""
weight: 4
---

This is the reference for [Email Templates]({{< ref "/concepts/email-templates" >}}).

It covers the available templates and shows how to override them.
