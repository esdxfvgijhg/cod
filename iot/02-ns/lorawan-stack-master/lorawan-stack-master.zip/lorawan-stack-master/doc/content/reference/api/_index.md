---
title: "API"
description: ""
weight: 1
---

This is the reference for the gRPC and HTTP APIs that The Things Stack exposes.
