---
title: "Join Server Options"
description: ""
weight: 6
---

## General Options

- `js.join-eui-prefix`: JoinEUI prefixes handled by this Join Server
