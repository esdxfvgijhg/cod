---
title: "Gateway Server APIs"
description: ""
weight: 6
---

## The `Gs` service

{{< proto/method service="Gs" method="GetGatewayConnectionStats" >}}

## Messages

{{< proto/message message="GatewayIdentifiers" >}}

{{< proto/message message="GatewayConnectionStats" >}}

{{< proto/message message="GatewayConnectionStats.RoundTripTimes" >}}

{{< proto/message message="GatewayStatus" >}}
