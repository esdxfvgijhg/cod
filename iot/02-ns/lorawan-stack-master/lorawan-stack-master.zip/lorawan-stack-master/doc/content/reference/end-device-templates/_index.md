---
title: "End Device Templates"
description: ""
weight: 3
---

This is the reference for [End Device Templates]({{< ref "/concepts/end-device-templates" >}}).

It covers how to create templates or convert from vendor-specific manifest files, how to map and combine templates, how to assign EUIs and how to execute the templates to create the end devices.
