---
title: "Getting Started"
description: ""
weight: 10
---

This is a guide for setting up a private LoRaWAN network server using The Things Stack for LoRaWAN.

In this guide we will get everything up and running on a server using [Docker](https://docs.docker.com/engine/) and [Docker Compose](https://docs.docker.com/compose/). If you are comfortable with configuring servers and working with command line, this is the perfect place to start.
