---
title: "Concepts"
description: ""
weight: 3
menu:
  main:
    weight: 3
---

This section describes key concepts on a high level to give an understanding of what it is, who it is for and how it works.
