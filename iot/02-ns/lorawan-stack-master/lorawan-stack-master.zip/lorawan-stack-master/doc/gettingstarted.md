# Getting Started with The Things Stack for LoRaWAN

For the latest Getting Started guide, visit [ttn.fyi/v3/getting-started](https://ttn.fyi/v3/getting-started).
