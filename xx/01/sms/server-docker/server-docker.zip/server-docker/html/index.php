<?php
header('Location: sensor-map');
